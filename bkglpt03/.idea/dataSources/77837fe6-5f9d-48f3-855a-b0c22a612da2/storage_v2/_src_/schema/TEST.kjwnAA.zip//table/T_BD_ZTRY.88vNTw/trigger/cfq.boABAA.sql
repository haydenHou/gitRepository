create trigger "cfq"
  before insert
  on T_BD_ZTRY
  BEGIN
  NULL;
END;
/

